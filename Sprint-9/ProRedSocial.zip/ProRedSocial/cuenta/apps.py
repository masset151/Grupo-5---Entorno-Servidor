from django.apps import AppConfig


class CuentaConfig(AppConfig):
    name = 'cuenta'
