from django.contrib import admin
from publicacion.models import Publicacion,Historia,VerHistoria,ConsultarPublicacion
# Register your models here.

admin.site.register(Publicacion)
admin.site.register(Historia)