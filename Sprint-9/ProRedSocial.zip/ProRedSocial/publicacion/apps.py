from django.apps import AppConfig


class PublicacionConfig(AppConfig):
    name = 'publicacion'
