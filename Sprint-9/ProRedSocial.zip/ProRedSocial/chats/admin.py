from django.contrib import admin
from chats.models import Chat

# Register your models here.

admin.site.register(Chat)
